const express = require("express");
const axios = require("axios");

const app = express();
app.use(express.json());

const WEATHER_API_KEY = "b9134ec1a26662e25cb517e35635d1f5";
const FRESHSERVICE_API_KEY = "FMC2m_atZtBHMGdQ_ILN";
const FRESHSERVICE_DOMAIN = "haass-io507.freshservice.com";

// Generate recommendation based on weather data
function generateRecommendation(weather, tripType) {
  const temp = Math.round(weather.main.temp - 273.15); // Kelvin to Celsius
  const description = weather.weather[0].description.toLowerCase();
  const humidity = weather.main.humidity;
  const windSpeed = weather.wind.speed;
  const city = weather.name;

  let weatherSummary = "";
  let advice = "";

  // Temperature based advice
  if (temp >= 30) {
    weatherSummary = `🌡️ Hot weather expected in ${city} (${temp}°C)`;
    advice += "Stay hydrated and avoid long outdoor walks during peak hours. ";
  } else if (temp >= 20) {
    weatherSummary = `☀️ Pleasant weather in ${city} (${temp}°C)`;
    advice += "Great conditions for outdoor activities. ";
  } else if (temp >= 10) {
    weatherSummary = `🌤️ Mild weather in ${city} (${temp}°C)`;
    advice += "Carry a light jacket for comfort. ";
  } else {
    weatherSummary = `🥶 Cold weather in ${city} (${temp}°C)`;
    advice += "Bundle up with warm clothing. ";
  }

  // Rain/condition based advice
  if (description.includes("rain") || description.includes("drizzle")) {
    advice += "High chance of rain — carry an umbrella and plan some indoor activities. ";
  } else if (description.includes("storm") || description.includes("thunder")) {
    advice += "Stormy conditions expected — prioritize indoor venues and stay safe. ";
  } else if (description.includes("snow")) {
    advice += "Snowy conditions — wear waterproof boots and drive carefully. ";
  } else if (description.includes("clear")) {
    advice += "Clear skies — perfect for outdoor sightseeing! ";
  } else if (description.includes("cloud")) {
    advice += "Cloudy skies but manageable — good for walking tours. ";
  }

  // Humidity advice
  if (humidity > 80) {
    advice += "High humidity — light breathable clothing recommended. ";
  }

  // Wind advice
  if (windSpeed > 10) {
    advice += "Windy conditions — secure loose items and avoid open areas. ";
  }

  // Trip type specific advice
  if (tripType === "Vacation") {
    advice += "Enjoy your vacation and explore local attractions!";
  } else if (tripType === "Business") {
    advice += "Allow extra travel time and keep formal attire weather-appropriate.";
  } else if (tripType === "Adventure") {
    advice += "Check local trail/activity conditions before heading out.";
  }

  return `${weatherSummary}\n\n🧳 Travel Recommendation:\n${advice}\n\n📊 Weather Details: ${description}, Humidity: ${humidity}%, Wind: ${windSpeed} m/s`;
}

// Post comment to Freshservice ticket
async function postComment(ticketId, comment) {
  const url = `https://${FRESHSERVICE_DOMAIN}/api/v2/tickets/${ticketId}/notes`;
  const auth = Buffer.from(`${FRESHSERVICE_API_KEY}:X`).toString("base64");

  await axios.post(
    url,
    {
      body: comment,
      private: false,
    },
    {
      headers: {
        Authorization: `Basic ${auth}`,
        "Content-Type": "application/json",
      },
    }
  );
}

// Main webhook endpoint
app.post("/recommend", async (req, res) => {
  console.log("Received request:", req.body);

  const { ticket_id, city, trip_type } = req.body;

  if (!ticket_id || !city) {
    return res.status(400).json({ error: "Missing ticket_id or city" });
  }

  try {
    // Call OpenWeatherMap API
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${WEATHER_API_KEY}`;
    const weatherResponse = await axios.get(weatherUrl);
    const weatherData = weatherResponse.data;

    // Generate recommendation
    const recommendation = generateRecommendation(weatherData, trip_type || "Vacation");

    // Post comment to Freshservice
    await postComment(ticket_id, recommendation);

    console.log(`✅ Recommendation posted for ticket ${ticket_id}`);
    res.json({ success: true, recommendation });

  } catch (error) {
    console.error("Error:", error.response?.data || error.message);
    res.status(500).json({ error: error.message });
  }
});

// Health check
app.get("/", (req, res) => {
  res.json({ status: "Weather Travel Middleware is running!" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
